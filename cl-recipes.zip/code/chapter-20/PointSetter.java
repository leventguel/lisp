package de.weitz;

public interface PointSetter {
  public void fill(boolean points[][]);
}
