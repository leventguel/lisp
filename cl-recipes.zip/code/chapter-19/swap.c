void swap (int *a, int *b) {
  int t = *b;
  *b = *a;
  *a = t;
}
